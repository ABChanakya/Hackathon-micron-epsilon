#include <cstring> // std::strstr
#include <cstdio> // std::printf, std::scanf, std::FILE, std::fopen, std::fclose, std::fread, std::fflush, std::getchar, std::snprintf
#include <cctype> // std::isspace
#include <limits> // std::numeric_limits
#include <algorithm> // std::min
#include <cmath> // std::log10
#include <array> // std::array
#include <vector> // std::vector
#include <string> // std::string
#if defined(_WIN32)
#include <conio.h> // _kbhit
#define MAX_PATH 260
#else // _WIN32
#include <sys/select.h> // FD_SET, select
#include <unistd.h> // STDIN_FILENO
#include <strings.h> // strcasecmp, strncasecmp
#define _stricmp strcasecmp
#define _strnicmp strncasecmp
#endif // WIN32
#include "../../MEDAQLib.h" // MEDAQLib.h must be included to know it's functions

#define MEAS_FREQUENCY // Measure real datarate of received signal
//#define CHECK_MONOTONY // Enable monotony check for counter values

static bool sSensorIsMEBUS= false;
static bool sSensorIsMultiSensor= false;
static bool sVideoStreamActive= false;
static bool sHTTPProxyActive= false;
static int32_t sValsPerFrame= 0;
#if defined (CHECK_MONOTONY)
static int32_t sCounterIndex= -1;
#endif

/** Helper function to set cursor at start of current line in console.
*/
void ClearLine()
	{
	std::printf ("\r"); // Jump at start of line, next std::printf will overwrite old content
	}

/** Show current progress in console.
*/
void ShowProgress (double progress)
	{
	std::printf ("Progress: %5.1f%%", progress);
#if !defined(_WIN32)
	std::fflush (stdout);
#endif
	}

/** Check if key was pressed, read character in case of.
*/
bool KeyPressed()
	{
#if defined(_WIN32)
	bool keyPressed= false;
	while (_kbhit())
		keyPressed|= _getch()!=0; // Function keys (F..., Ctrl-C, ...) writer two characters into keyboard buffer (first may be 0), so call getch() multiple times
	return keyPressed;
#else // _WIN32
	struct timeval tv= {};
	fd_set rdfs;
	FD_ZERO (&rdfs);
	FD_SET (STDIN_FILENO, &rdfs);

	select (STDIN_FILENO+1, &rdfs, nullptr, nullptr, &tv);
	if (FD_ISSET (STDIN_FILENO, &rdfs))
		{
		std::getchar();
		return true;
		}
	return false;
#endif //ifdef WIN32
	}

/** Close and release sensor instance, wait for a key pressed
*/
int32_t Cleanup (uint32_t sensorInstance, int32_t retCode= 0)
	{
	if (sensorInstance!=0)
		{
		::CloseSensor (sensorInstance);
		::ReleaseSensorInstance (sensorInstance);
		}
	std::printf ("Press any key to exit");
#if !defined(_WIN32)
	std::fflush (stdout);
#endif // !_WIN32
	while (!KeyPressed())
		; // busy waiting
	return retCode;
	}

/** Generate a parameter name with index and return vector by move semantic
*/
std::vector<char> StrWithIndex (const char *formatStr, int32_t index)
	{
	std::vector<char> buffer (std::strlen (formatStr)+static_cast<std::size_t>(std::log10 (index))+1);
	std::sprintf (buffer.data(), formatStr, index);
	return buffer;
	}

/** Extract a string parameter and return result vector
*/
ERR_CODE GetParameterString (uint32_t sensorInstance, const char *parameterName, std::vector<char> &result)
	{
	uint32_t length= 0;
	ERR_CODE ret= ::GetParameterString (sensorInstance, parameterName, nullptr, &length);
	if (ret!=ERR_NOERROR)
		return ret;
	result.resize (length+1);
	ret= ::GetParameterString (sensorInstance, parameterName, result.data(), &length);
	result[length]= '\0';
	return ret;
	}

/** Retrieve error message after any MEDAQLib function returned an error
*/
void ShowLastError (uint32_t sensorInstance, const char *location)
	{
	std::array<char, 2048> errorBuffer= {}; // enough to hold error message
	ERR_CODE ret= ::GetError (sensorInstance, errorBuffer.data(), static_cast<uint32_t>(errorBuffer.size()));
	if (ret==ERR_NOERROR)
		return;
	std::printf ("\nError %d at '%s'\n", ret, location);
	std::printf ("%s\n", errorBuffer.data());

	int32_t errNumber= 0;
	if (::GetParameterInt (sensorInstance, "SA_ErrorNumber", &errNumber)==ERR_NOERROR)
		std::printf ("Sensor error number: %d\n", errNumber);

	std::vector<char> errorText;
	if (GetParameterString (sensorInstance, "SA_ErrorText", errorText)==ERR_NOERROR)
		std::printf ("Sensor error text: '%s'\n", errorText.data());
	}

/** Macro to encapsulate error handling when calling MEDAQLib functions.
* Can only be used if variable sensorInstance exists.
*/
#define CHECK_ERROR(expr) \
	{ \
	const ERR_CODE ceRet= expr; \
	if (ceRet!=ERR_NOERROR) \
		{ \
		ShowLastError (sensorInstance, #expr); \
		if (ceRet!=ERR_WARNING && ceRet!=ERR_SENSOR_ANSWER_WARNING) \
			return false; \
		} \
	}

/** Print short help on console
*/
void Usage()
	{
	std::printf ("Usage:\nSensorTest <Sensor name> [InterfaceParam=Value] ...\n");
	std::printf ("Value can be an integer number (without dot) or a double number (with dot) or a string.\n");
	std::printf ("If a parameter contains a space, it must be quoted by \"...\".\n");
	std::printf ("If a command file should be processed after connecting, set parameter Commands=\"<File name>\"\n");
	std::printf ("Examples:\n");
	std::printf ("SensorTest ILD2300 (will use SensorFinder to detect ILD2300)\n");
	std::printf ("SensorTest IFD2451 IP_Interface=TCP/IP IP_RemoteAddr=192.168.1.10 (connect to IFD2451 via TCP/IP on a fixed address)\n\n");
	std::printf ("Format of command file:\n");
	std::printf ("Each command is at an own line. Command parameters are separated by spaces.\n");
	std::printf ("A command line is limited to 2048 characters.\n");
	std::printf ("If parameter S_Command is missing the whole line is skipped.\n");
	std::printf ("E.g.: S_Command=Set_DataOutInterface SP_DataOutInterface=2\n\n");
	std::printf ("Instead of <Sensor name> a control file may be specified: \nSensorTest Control=\"<File name>\"\nIn this case any following parameters are ignored.\n");
	std::printf ("Format of control file is same as command file, but at start there must be additional information.\n");
	std::printf ("First the sensor name must be specified. Than the interface parameters may follow (in same form as in command line).\nIn the following lines the commands may follow.\n");
	}

/** Read a command or control file into a vector
*/
bool ReadFile (std::vector<char> &buffer, const char *fileName)
	{
	std::FILE *f= std::fopen (fileName, "rb");
	if (!f)
		{
#if defined (_WIN32)
		char fullPathName[MAX_PATH]= {};
		fileName= _fullpath (fullPathName, fileName, MAX_PATH);
#endif
		std::printf ("Could not open command/control file '%s'\n", fileName);
		return false;
		}
  std::fseek (f, 0, SEEK_END); // seek to end
  const std::size_t filesize= std::ftell (f);
	buffer.resize (filesize+1);

  std::fseek (f, 0, SEEK_SET); // seek to start
  if (std::fread (buffer.data(), sizeof (char), filesize, f)!=filesize || std::ferror (f))
		{
		std::printf ("Error reading command/control file\n");
		return false;
		}
	buffer[filesize]= '\0';
	std::fclose (f);
	return true;
}

/** Skip white spaces and comments (from # to line end) within a vector
*/
std::vector<char>::iterator SkipComments (std::vector<char>::iterator actPos, std::vector<char>::iterator end)
	{
	bool inComment= false;
	while (actPos!=end)
		{
		if (*actPos=='#')
			inComment= true;
		else if (inComment && *actPos=='\n')
			inComment= false;
		else if (!inComment && !std::isspace (*actPos) && *actPos!='\0')
			break;
		++actPos;
		}
	return actPos;
	}

/** Extract sensor type name from vector
*/
const char *ExtractSensorTypeName (std::vector<char>::iterator &actPos, std::vector<char>::iterator end)
	{
	const char *ret= &(*actPos);
	while (actPos!=end)
		{
		if (std::isspace (*actPos))
			{
			*actPos= '\0';
			break;
			}
		++actPos;
		}
	actPos= SkipComments (actPos, end);
	return ret;
	}

/** Extract interface parameters from vector
*/
const char *ExtractInterfaceParameters (std::vector<char>::iterator &actPos, std::vector<char>::iterator end)
	{
	const char *ret= &(*actPos);
	while (actPos!=end)
		{
		if (end-actPos<9) // no more space for S_Command
			actPos= end;
		else
			{
			if (std::strncmp (&(*actPos), "S_Command", 9)==0)
				{
				*(actPos-1)= '\0';
				if (ret==&(*actPos))
					ret--;
				break;
				}
			actPos= SkipComments (++actPos, end);
			}
		}
	actPos= SkipComments (actPos, end);
	return ret;
	}

/** Extract sensor command (one line) from vector
*/
const char *ExtractSensorCommand (std::vector<char>::iterator &actPos, std::vector<char>::iterator end)
	{
	const char *ret= &(*actPos);
	while (actPos!=end)
		{
		if (*actPos=='\n')
			{
			*actPos= '\0';
			break;
			}
		++actPos;
		}
	if (actPos!=end)
		actPos= SkipComments (++actPos, end);
	return ret;
	}

/** Parse and store interface parameters within sensor instance
*/
bool ParseInterfaceParameters (uint32_t sensorInstance, int32_t count, const char *const buffer[])
	{
	if (!buffer)
		return false;
	for (int32_t i=0 ; i<count ; i++)
		CHECK_ERROR (::SetParameters  (sensorInstance, buffer[i]));
	return true;
	}

/** Convert a parity enum to a string
*/
const std::string &ParityToString (uint32_t parity)
	{
	static const std::array<std::string, 6> strings= { "No parity", "Odd parity", "Even parity", "Mark parity", "Space parity", "Invalid parity" };
	return parity<strings.size() ? strings[parity] : strings.back();
	}

/** Convert a stop bit enum to a string
*/
const std::string &StopbitsToString (uint32_t stopbits)
	{
	static const std::array<std::string, 4> strings= { "One stop bit", "One point five stop bits", "Two stop bits", "Invalid stop bits" };
	return stopbits<strings.size() ? strings[stopbits] : strings.back();
	}

/** Print RS232 interface parameters at console
*/
bool PrintRS232 (uint32_t sensorInstance)
	{
	std::vector<char> port;
	int32_t baudrate= 0, byteSize= 0, parity= 0, stopbits= 0, sensorAddress= 0;
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_Port", port));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_Baudrate", &baudrate));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_ByteSize", &byteSize));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_Parity", &parity));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_Stopbits", &stopbits));
	std::printf ("%s, %d Baud, %d data bits, %s, %s", port.data(), baudrate, byteSize, ParityToString (parity).c_str(), StopbitsToString (stopbits).c_str());
	if (::GetParameterInt (sensorInstance, "IP_SensorAddress", &sensorAddress)==ERR_NOERROR)
		std::printf (", RS485 addr: %d", sensorAddress);
	return true;
	}

/** Print TCP/IP interface parameters at console
*/
bool PrintTCPIP (uint32_t sensorInstance)
	{
	std::vector<char> ipAddress;
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_RemoteAddr", ipAddress));
	std::printf ("%s", ipAddress.data());
	return true;
	}

/** Print USB interface parameters at console
*/
bool PrintUSB (uint32_t sensorInstance)
	{
	int32_t deviceInstance= 0;
	CHECK_ERROR (::GetParameterInt  (sensorInstance, "IP_DeviceInstance", &deviceInstance));
	std::printf ("Instance %d", deviceInstance);
	return true;
	}

/** Print IF2004_USB parameters at console
*/
bool PrintIF2004_USB (uint32_t sensorInstance)
	{
	int32_t deviceInstance= 0, channelNumber= 0, baudrate= 0;
	std::vector<char> serialNumber, port;
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_DeviceInstance", &deviceInstance));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_ChannelNumber", &channelNumber));
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_Port", port));
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_SerialNumber", serialNumber));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_Baudrate", &baudrate));
	std::printf ("Device %d (SN%s, %s), Channel %d, %d Baud", deviceInstance, serialNumber.data(), port.data(), channelNumber, baudrate);
	return true;
	}

/** Print IF2008 interface parameters at console
*/
bool PrintIF2008 (uint32_t sensorInstance)
	{
	int32_t cardInstance= 0, channelNumber= 0, baudrate= 0, parity= 0;
	CHECK_ERROR (::GetParameterInt  (sensorInstance, "IP_CardInstance", &cardInstance));
	CHECK_ERROR (::GetParameterInt  (sensorInstance, "IP_ChannelNumber", &channelNumber));
	CHECK_ERROR (::GetParameterInt  (sensorInstance, "IP_Baudrate", &baudrate));
	CHECK_ERROR (::GetParameterInt  (sensorInstance, "IP_Parity", &parity));
	std::printf ("Card %d, Channel %d, %d Baud, %s", cardInstance, channelNumber, baudrate, ParityToString (parity).c_str());
	return true;
	}

/** Print IF2008_ETH interface parameters at console
*/
bool PrintIF2008_ETH (uint32_t sensorInstance, bool showSensorParam)
	{
	std::vector<char> ipAddress;
	int32_t channelNumber= 0, baudrate= 0;
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_RemoteAddr", ipAddress));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_ChannelNumber", &channelNumber));
	std::printf ("%s, Channel %d", ipAddress.data(), channelNumber);
	if (showSensorParam)
		{
		CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_Baudrate", &baudrate));
		std::printf (", %d Baud", baudrate);
		}
	return true;
	}

/** Show one result of SensorFinder at console
*/
bool ShowFoundSensor (uint32_t sensorInstance, int32_t sensorIndex)
	{
	CHECK_ERROR (::SetIntExecSCmd (sensorInstance, "Get_FoundSensor", "IP_Index", sensorIndex));
	std::vector<char> sensorTypeName, hwInterfaceName, serialNumber;
	int32_t sensorType= 0, hardwareInterface= 0;
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_SensorType", &sensorType));
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_SensorTypeName", sensorTypeName));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_InterfaceIdx", &hardwareInterface));
	CHECK_ERROR (GetParameterString (sensorInstance, "IP_Interface", hwInterfaceName));
	std::printf ("%d: %s at %s (", sensorIndex, sensorTypeName.data(), hwInterfaceName.data());
	switch (hardwareInterface)
		{
		case  1: if (!PrintRS232      (sensorInstance)) return false; break;
		case  2: /* IF2004/PCI is no longer supported */              break;
		case  3: if (!PrintTCPIP      (sensorInstance)) return false; break;
		case  4: if (!PrintUSB        (sensorInstance)) return false; break;
		case  5: if (!PrintUSB        (sensorInstance)) return false; break;
		case  6: if (!PrintIF2008     (sensorInstance)) return false; break;
		case  7: if (!PrintUSB        (sensorInstance)) return false; break;
		case  8: if (!PrintIF2004_USB (sensorInstance)) return false; break;
		case 10: if (!PrintIF2008_ETH (sensorInstance, sensorType!=ETH_ADAPTER_IF2008)) return false; break;
		}
	std::printf (")");
	if (GetParameterString (sensorInstance, "SA_SerialNumber", serialNumber)==ERR_NOERROR)
		std::printf (", Serial number %s", serialNumber.data());
	std::printf ("\n");
	return true;
	}

/** Seach for specified sensor at any interface and selects one sensor
*/
bool SensorFinder (uint32_t &sensorInstance)
	{
	int32_t enableLogging= 0;
	::GetParameterInt (sensorInstance, "IP_EnableLogging", &enableLogging);
	if (enableLogging)
		CHECK_ERROR (::SetIntExecSCmd (sensorInstance, "Enable_Logging", "CP_ClearSendParameters", 0)); // set Enable_Logging but keep parameters in sensor instance

	std::printf ("Scanning for sensors (press any key to abort)\n");
	double progress= 0.0;
	int32_t found= 0, processed= 0;
	ShowProgress (progress);
	CHECK_ERROR (::ExecSCmd (sensorInstance, "Start_FindSensor"));
	do
		{
		CHECK_ERROR (::SetDoubleExecSCmd (sensorInstance, "Exec_SleepTime", "IP_SleepTime", 50.0/*ms*/));
		ClearLine();
		CHECK_ERROR (::ExecSCmdGetDouble (sensorInstance, "Get_FindSensorProgress", "IA_Progress", &progress));
		CHECK_ERROR (::GetParameterInt   (sensorInstance, "IA_Found", &found));
		while (found>processed)
			if (!ShowFoundSensor (sensorInstance, processed++))
				return false;
		if (KeyPressed())
			CHECK_ERROR (::ExecSCmd (sensorInstance, "Abort_FindSensor"));
		ShowProgress (progress);
		} while (progress<100.0);
	ClearLine();

	int32_t sensorIndex= -1;
	if (found<=0)
		{
		std::printf ("Specified sensor is not found\n");
		return false;
		}
	else if (found==1)
		sensorIndex= 0;
	else // more sensors found
		{
		std::printf ("Please type sensor index <CR> to open sensor: ");
		const int32_t cnt= std::scanf ("%d", &sensorIndex);
		if (cnt!=1 || sensorIndex<0 || sensorIndex>=found)
			{
			std::printf ("No valid sensor selected\n");
			return false;
			}
		}
	// Following function requests all interface parameters for selected sensor. Now it can be used at OpenSensor.
	CHECK_ERROR (::SetIntExecSCmd (sensorInstance, "Get_FoundSensor", "IP_Index", sensorIndex));
	int32_t similarSensor= 0;
	::GetParameterInt (sensorInstance, "IP_SimilarSensor", &similarSensor); // Ignore error if parameter does not exist
	if (similarSensor!=0) // Other sensor as expected was found (if IP_FindSimilarSensors is set)
		{
		ME_SENSOR sensorType= NO_SENSOR;
		CHECK_ERROR (::GetParameterInt (sensorInstance, "IP_SensorType", reinterpret_cast<int32_t *>(&sensorType)));
		uint32_t len= 0;
		CHECK_ERROR (::GetParameters (sensorInstance, nullptr, &len));
		std::vector<char> parameterList (len+1);
		CHECK_ERROR (::GetParameters (sensorInstance, parameterList.data(), &len));
		parameterList[len]= '\0';
		const uint32_t oldInstance= sensorInstance;
		sensorInstance= ::CreateSensorInstance (sensorType); // so create a new one using correct sensor type
		CHECK_ERROR (::SetParameters (sensorInstance, parameterList.data()));
		::ReleaseSensorInstance (oldInstance); // and release old instance
		}
	return true;
	}

/** Connect to sensor
*/
bool Open (uint32_t sensorInstance)
	{
	std::printf ("Connecting to sensor\n");
	CHECK_ERROR (::OpenSensor (sensorInstance));
	return true;
	}

bool ProcessSensorCommands (uint32_t sensorInstance, std::vector<char>::iterator actPos, std::vector<char>::iterator end)
	{
	while (actPos!=end)
		{
		const char *command= ExtractSensorCommand (actPos, end);
		CHECK_ERROR (::ClearAllParameters (sensorInstance));
		CHECK_ERROR (::SetParameters (sensorInstance, command));
		std::printf ("Executing command: %s", command);
		const ERR_CODE ret= ::SensorCommand (sensorInstance);
		if (ret!=ERR_NOERROR)
			ShowLastError (sensorInstance, "SensorCommand");
		else
			std::printf ("\nSuccess!\n");
		if (ret==ERR_NOERROR || ret==ERR_WARNING || ret==ERR_SENSOR_ANSWER_WARNING)
			{
			uint32_t len= 0;
			CHECK_ERROR (::GetParameters (sensorInstance, nullptr, &len));
			std::vector<char> answer (len+1);
			CHECK_ERROR (::GetParameters (sensorInstance, answer.data(), &len));
			answer[len]= '\0';
			std::printf ("\nAnswer parameters: %s\n", answer.data());
			if (std::strstr (command, "Start_HTTP2SensorProxy")!=nullptr)
				sHTTPProxyActive= true;
			else if (std::strstr (command, "Stop_HTTP2SensorProxy")!=nullptr)
				sHTTPProxyActive= false;
			}
		}
	return true;
	}

/** Retrieve information about transmitted data from sensor and show it at console
*/
bool GetTransmittedDataInfo (uint32_t sensorInstance)
	{
	int32_t maxValsPerFrame= 0, maxOutputIndex= 0;
#if defined (CHECK_MONOTONY)
	char sMonotony[512]= {};
#endif
	CHECK_ERROR (::ExecSCmdGetInt (sensorInstance, "Get_TransmittedDataInfo", "IA_ValuesPerFrame", &sValsPerFrame));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IA_MaxValuesPerFrame", &maxValsPerFrame));
	CHECK_ERROR (::GetParameterInt (sensorInstance, "IA_MaxOutputIndex", &maxOutputIndex));

	std::printf ("\nSensor transmits %d of %d possible values, maximum output index is %d\n", sValsPerFrame, maxValsPerFrame, maxOutputIndex);
	for (int32_t i=0 ; i<sValsPerFrame ; i++)
		{
		int32_t index= 0;
		double rawRangeMin= 0.0, rawRangeMax= 0.0, scaledRangeMin= 0.0, scaledRangeMax= 0.0;
		std::vector<char> rawName, scaledName, rawUnit, scaledUnit, additionalInfo;
		CHECK_ERROR (GetParameterString (sensorInstance, StrWithIndex ("IA_Raw_Name%d", i+1).data(), rawName));
		CHECK_ERROR (GetParameterString (sensorInstance, StrWithIndex ("IA_Scaled_Name%d", i+1).data(), scaledName));
		CHECK_ERROR (GetParameterString (sensorInstance, StrWithIndex ("IA_Raw_Unit%d", i+1).data(), rawUnit));
		CHECK_ERROR (GetParameterString (sensorInstance, StrWithIndex ("IA_Scaled_Unit%d", i+1).data(), scaledUnit));
		CHECK_ERROR (::GetParameterInt (sensorInstance, StrWithIndex ("IA_Index%d", i+1).data(), &index));
		CHECK_ERROR (::GetParameterDouble (sensorInstance, StrWithIndex ("IA_Raw_RangeMin%d", i+1).data(), &rawRangeMin));
		CHECK_ERROR (::GetParameterDouble (sensorInstance, StrWithIndex ("IA_Scaled_RangeMin%d", i+1).data(), &scaledRangeMin));
		CHECK_ERROR (::GetParameterDouble (sensorInstance, StrWithIndex ("IA_Raw_RangeMax%d", i+1).data(), &rawRangeMax));
		CHECK_ERROR (::GetParameterDouble (sensorInstance, StrWithIndex ("IA_Scaled_RangeMax%d", i+1).data(), &scaledRangeMax));
		GetParameterString (sensorInstance, StrWithIndex ("IA_AdditionalInfo%d", i+1).data(), additionalInfo); // may exist
		std::replace (additionalInfo.begin(), additionalInfo.end(), '\r', ' ');
		std::replace (additionalInfo.begin(), additionalInfo.end(), '\n', ' ');

		char addInfo[1024]= {};
		if (std::strlen (additionalInfo.data())>0)
			std::sprintf (addInfo, " (%s)", additionalInfo.data());
		std::printf (" %2d: %s [%.1f .. %.1f %s], %s [%g .. %g %s]%s\n", index, rawName.data(), rawRangeMin, rawRangeMax, rawUnit.data(), scaledName.data(), scaledRangeMin, scaledRangeMax, scaledUnit.data(), addInfo);
#if defined (CHECK_MONOTONY)
		if (sCounterIndex==-1 && std::strstr (scaledName.data(), "Counter")!=nullptr)
			{
			sCounterIndex= i;
			std::snprintf (sMonotony, sizeof (sMonotony), "Enable monotony check for signal %2d: %s\n", index, scaledName.data());
			}
#endif
		} // for
	double samplerate= 0.0, datarate= 0.0;
	CHECK_ERROR (::GetParameterDouble (sensorInstance, "IA_Samplerate", &samplerate));
	CHECK_ERROR (::GetParameterDouble (sensorInstance, "IA_Datarate", &datarate));
	std::printf ("Samplerate: %.1f Hz, Datarate: %.1f Hz\n", samplerate, datarate);

	int32_t videoSignalsPerFrame= 0;
	::GetParameterInt (sensorInstance, "IA_VideoSignalsPerFrame", &videoSignalsPerFrame); // This parameter may not exist, so ignore errors
	if (videoSignalsPerFrame>0)
		{
		sVideoStreamActive= true;
		std::printf ("\nSensor transmits %d video signals\n", videoSignalsPerFrame);
		for (int32_t i=0; i<videoSignalsPerFrame; i++)
			{
			std::vector<char> videoSignalName;
			int32_t videoSignalPixelCount= 0, videoSignalPixelByteSize= 0;
			CHECK_ERROR (::GetParameterString (sensorInstance, StrWithIndex ("IA_VideoSignalName%d", i+1).data(), videoSignalName));
			CHECK_ERROR (::GetParameterInt    (sensorInstance, StrWithIndex ("IA_VideoSignalPixelCount%d", i+1).data(), &videoSignalPixelCount));
			CHECK_ERROR (::GetParameterInt    (sensorInstance, StrWithIndex ("IA_VideoSignalPixelByteSize%d", i+1).data(), &videoSignalPixelByteSize));

			std::printf (" %s (%d pixel each %d bytes) with length %d bytes\n", videoSignalName.data(), videoSignalPixelCount, videoSignalPixelByteSize, videoSignalPixelCount*videoSignalPixelByteSize);
			}
		}
#if defined (CHECK_MONOTONY)
	if (sCounterIndex!=-1)
		std::printf ("%s", sMonotony);
#endif
	return true;
	}

#if defined (CHECK_MONOTONY)
bool CheckMonotony (uint32_t sensorInstance, int32_t count, const double *values, int32_t overflow)
	{
	if (sCounterIndex<0)
		return true;
	static double sLastVal= -1.0;
	if (overflow!=0)
		{
		char buf[256]= {};
		std::sprintf (buf, "\nToo much data, %d values (%d frames) discarded, unwarranted monotony error may occur!\n", overflow, overflow/sValsPerFrame);
		CHECK_ERROR (::LogToFile (sensorInstance, 8/*WARNING_LEVEL*/, "SensorTest::CheckMonotony", buf));
		std::printf ("%s", buf);
		}
	for (int32_t i=0; i<count; i+= sValsPerFrame)
		{
		if (sLastVal!=-1.0/*at Start*/ && values[sCounterIndex+i]!=0.0/*wrap around after overflow*/ && values[sCounterIndex+i]-sLastVal!=1.0)
			{
			char buf[256]= {};
			std::sprintf (buf, "\nMonotony error: %.0f .. %.0f -> missing %d frames\n", sLastVal, values[sCounterIndex+i], static_cast<int32_t>(values[sCounterIndex+i]-sLastVal-1.0));
			CHECK_ERROR (::LogToFile (sensorInstance, 4/*ERROR_LEVEL*/, "SensorTest::CheckMonotony", buf));
			std::printf ("%s", buf);
			}
		sLastVal= values[sCounterIndex+i];
		}
	if (overflow!=0)
		sLastVal+= overflow/sValsPerFrame;
	return true;
	}
#endif

#if defined (MEAS_FREQUENCY)
double MeasureFrequency (uint32_t sensorInstance, int32_t actValues)
	{
	static double sValues= 0.0, sStart= 0.0;
	double actual= 0.0;
	::ExecSCmdGetDouble (sensorInstance, "Get_HighResolutionTime", "IA_HighResolutionTime", &actual);
	if (sStart==0.0) // First time
		{
		sStart= actual;
		return 0.0;
		}
	sValues+= actValues;
	return sValues / (actual-sStart) * 1000.0 /*[Hz]*/;
	}
#endif

bool OutputTimeReached (uint32_t sensorInstance)
	{
	static const double OutputIntervall= 100.0/*ms*/;
	static double sLastTime= 0.0;
	double actual= 0.0;
	::ExecSCmdGetDouble (sensorInstance, "Get_HighResolutionTime", "IA_HighResolutionTime", &actual);
	if (actual-sLastTime>=OutputIntervall)
		{
		sLastTime= actual;
		return true;
		}
	else
		return false;
	}

/** Read continuous data from sensor and show each first frame at console
*/
bool GetData (uint32_t sensorInstance)
	{
	static const int32_t BufSize= 30000;
	static const double SleepTime= 25.0;

	std::array<int32_t, BufSize> rawData;
	std::array<double, BufSize> scaledData;

	if (!sHTTPProxyActive)
		std::printf ("\nReading data continuous (press any key to abort)\n");
	else
		std::printf ("\nRunning HTTP sensor proxy (press any key to abort)\n");
	while (!KeyPressed())
		{
		if (sSensorIsMEBUS)
			{
			if (sSensorIsMultiSensor)
				CHECK_ERROR (::SetIntExecSCmd (sensorInstance, "Get_Measure", "IP_SensorIndex", -1))
			else
				CHECK_ERROR (::ExecSCmd (sensorInstance, "Get_Measure"));
			}
		else // if (SleepTime>0) // always true, do not call Exec_SleepTime if SleepTime==0
			CHECK_ERROR (::SetDoubleExecSCmd (sensorInstance, "Exec_SleepTime", "IP_SleepTime", SleepTime/*ms*/));
		if (sVideoStreamActive)
			{
			::SetParameterInt (sensorInstance, "SP_ReadMode", 2/*Automatic*/);
			::SetParameterDouble (sensorInstance, "SP_WaitVideoTimeout", 500.0/*ms*/);
			CHECK_ERROR (::ExecSCmd (sensorInstance, "Get_VideoStreamSignal"));
			// Possible implementation to extract video signal (please replace signal name according to your sensor):
			//std::array<uint16_t, 512> videoBuffer;
			//uint32_t maxLen= videoBuffer.size()*sizeof (uint16_t);
			//CHECK_ERROR (::GetParameterBinary (sensorInstance, "SA_VideoRaw", reinterpret_cast<uint8_t *>(videoBuffer.data()), &maxLen));
			}
		if (sHTTPProxyActive)
			{
			if (OutputTimeReached (sensorInstance))
				{
				int32_t cnt= 0;
				CHECK_ERROR (::ExecSCmdGetInt (sensorInstance, "Get_OpenHTTPConnections", "CA_OpenHTTPConnections", &cnt));
				ClearLine();
				std::printf("Open connections: %d", cnt);
				}
			ShowLastError (sensorInstance, "HTTP proxy server");
			continue;
			}
		int32_t avail= 0;
		CHECK_ERROR (::DataAvail (sensorInstance, &avail));
		if (avail<sValsPerFrame)
			continue;
		int32_t read= avail;
		if (read>BufSize)
			read= BufSize;
		double timestamp= 0.0;
		CHECK_ERROR (::TransferDataTS (sensorInstance, rawData.data(), scaledData.data(), read, &read, &timestamp)); // Read up to [buffer size] values
		if (read<sValsPerFrame)
			{
			std::printf ("Error at '::TransferDataTS (sensorInstance, rawData, scaledData, BufSize, &read)'\nTo less values (%d) was read.\n", read);
			return false;
			}
		if (avail>read) // More data avail?
			CHECK_ERROR (::TransferData (sensorInstance, nullptr, nullptr, avail-read, nullptr)); // Read rest of values without processing to avoid buffer overflows
#if defined (MEAS_FREQUENCY)
		const double frequency= sValsPerFrame ? MeasureFrequency (sensorInstance, avail)/sValsPerFrame : 0.0;
#endif
#if defined (CHECK_MONOTONY)
		CheckMonotony (sensorInstance, read, scaledData.data(), avail-read);
#endif

		if (OutputTimeReached (sensorInstance))
			{
			ClearLine();
			std::printf ("[%5d/%5d] ", read, avail);
			for (int32_t i=0; i<sValsPerFrame; i++)
				{
				if (scaledData[i]==std::numeric_limits<double>::lowest()) // MEDAQLib default error value
					std::printf ("%u (error value)", static_cast<uint32_t>(rawData[i]));
				else
					std::printf ("%u (%-.3f)", static_cast<uint32_t>(rawData[i]), scaledData[i]);
				if (i<sValsPerFrame-1)
					std::printf (", ");
				}
			std::printf (", TS %.3f", timestamp);
#if defined (MEAS_FREQUENCY)
			std::printf (" @ %.3f Hz", frequency);
#endif
#if !defined(_WIN32)
			std::fflush (stdout);
#endif //if not def Win32
			} // OutputTimeReached()
		} // while (!KeyPressed());
	std::printf ("\n");
	if (sHTTPProxyActive)
		{
		std::printf ("Stopping HTTP proxy server\n");
		::ExecSCmd (sensorInstance, "Stop_HTTP2SensorProxy");
		}
	return true;
	}

/** Main SensorTest program
*/
int main (int argc, char *argv[])
	{
	if (argc<2 || !argv)
		return Usage(), Cleanup (0);

	std::vector<char> ctrlFile;
	auto actFilePos= ctrlFile.end();
	const char *sensorTypeName= nullptr,
	      *interfaceParameters= nullptr;

	if (_strnicmp (argv[1], "Control=", 8)==0)
		{
		if (!ReadFile (ctrlFile, argv[1]+8))
			return Cleanup (0, -1);
		actFilePos= SkipComments (ctrlFile.begin(), ctrlFile.end());
		sensorTypeName= ExtractSensorTypeName (actFilePos, ctrlFile.end());
		interfaceParameters= ExtractInterfaceParameters (actFilePos, ctrlFile.end());
	}
	else
		sensorTypeName= argv[1];

	uint32_t sensorInstance= ::CreateSensorInstByName (sensorTypeName);
	std::printf ("SensorTest %s\n", sensorTypeName);
	if (sensorInstance==0)
		{
		std::printf ("Cannot create MEDAQLib instance of sensor '%s'!\n", sensorTypeName);
		return Cleanup (sensorInstance, -2);
		}

	if ((_stricmp (sensorTypeName, "MEbus")==0) || (_stricmp (sensorTypeName, "ME-Bus")==0) || (_stricmp (sensorTypeName, "DT6120")==0) || (_stricmp (sensorTypeName, "capaNCDT 6120")==0))
		sSensorIsMEBUS = true;
	else if ((_stricmp (sensorTypeName, "MultiSensor")==0))
		sSensorIsMultiSensor= true;

	if (interfaceParameters)
		{
		if (!ParseInterfaceParameters (sensorInstance, 1, &interfaceParameters))
			return Cleanup (sensorInstance, -3);
		}
	else
		{
		if (!ParseInterfaceParameters (sensorInstance, argc-2, argv+2))
			return Cleanup (sensorInstance, -4);

		std::vector<char> cmdFileName;
		if (GetParameterString (sensorInstance, "Commands", cmdFileName)==ERR_NOERROR)
			{
			if (!ReadFile (ctrlFile, cmdFileName.data()))
				return Cleanup (sensorInstance, -5);
			actFilePos= SkipComments (ctrlFile.begin(), ctrlFile.end());
			}
		}

	uint32_t tmp= 0;
	if (::GetParameterString (sensorInstance, "IP_Interface", nullptr, &tmp)==ERR_NOT_FOUND && !sSensorIsMultiSensor) // Interface not specified and not MultiSensor,
		{
		if (!SensorFinder (sensorInstance)) // so start SensorFinder
			return Cleanup (sensorInstance, -6);
		if (interfaceParameters)
			{
			if (!ParseInterfaceParameters (sensorInstance, 1, &interfaceParameters))
				return Cleanup (sensorInstance, -7);
			}
		else
			{
			if (!ParseInterfaceParameters (sensorInstance, argc-2, argv+2))
				return Cleanup (sensorInstance, -8);
			}
		}

	if (!Open (sensorInstance))
		return Cleanup (sensorInstance, -9);

	// Sample for how to use LogToFile to get information into MEDAQLib Log File
	::LogToFile (sensorInstance, 16/*= NOTICE_LEVEL*/, "SensorTest", "Number of command line arguments: %d", argc);
	for (int i=0 ; i<argc ; i++)
		::LogToFile (sensorInstance, 16/*= NOTICE_LEVEL*/, "SensorTest", "Argument %d: %s", i+1, argv[i]);

	if (sSensorIsMultiSensor)
		{
		int32_t sensorType= NO_SENSOR;
		if (::ExecSCmdGetInt (sensorInstance, "Get_DrvSetting", "IA_SensorType#1", &sensorType)==ERR_NOERROR && (sensorType==SENSOR_ON_MEBUS || sensorType==SENSOR_DT6120))
			sSensorIsMEBUS= true; // If first sensor is MEBus assume any sensor is MEBus
		}

	if (!ProcessSensorCommands (sensorInstance, actFilePos, ctrlFile.end()))
		return Cleanup (sensorInstance, -10);

	if (!GetTransmittedDataInfo (sensorInstance))
		return Cleanup (sensorInstance, -11);

	if (!GetData (sensorInstance))
		return Cleanup (sensorInstance, -12);

	return Cleanup (sensorInstance);
	}
